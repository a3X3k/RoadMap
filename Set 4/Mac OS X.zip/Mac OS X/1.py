from PIL import Image,ImageChops
final=Image.open(r'nsW38Dh7Qx0.jpg')
final1=ImageChops.invert(final)
for i in range(0,300):
    s='nsW38Dh7Qx'+str(i)+'.jpg'
    img=Image.open(s)
    inv=ImageChops.invert(img)
    Image.Image.paste(final1,s,(0,0))    
    #final1.paste(s,(0,0),mask=s)
