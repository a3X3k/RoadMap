# 0 1 1 0

### Description

I found these files in my friends system and I am thinking that there is some useful information hidden it. Can you help in finding it?
